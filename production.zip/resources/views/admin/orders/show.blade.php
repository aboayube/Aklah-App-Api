{{$wasfa}}
{{dd($wasfa_content)}}