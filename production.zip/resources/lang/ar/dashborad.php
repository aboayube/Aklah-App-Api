<?php

return [
    'appname'=>'تطبيق',
    'dashborad'=>'',
    
];
