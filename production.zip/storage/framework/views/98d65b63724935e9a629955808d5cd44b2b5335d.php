<?php echo e($wasfa); ?>

<?php echo e(dd($wasfa_content)); ?><?php /**PATH E:\مشروع الهاكثون\first\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>