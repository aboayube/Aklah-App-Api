
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-xl-12">
        <div class="card mg-b-20">
            <div class="card-header pb-0">
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered table-arabic" id="sampleTable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0">#</th>
                                <th class="border-bottom-0">مستخدم </th>
                                <th class="border-bottom-0">تقييم </th>
                                <th class="border-bottom-0">ملاحظات </th>
                                <th class="border-bottom-0">note_en </th>
                                <?php if(auth()->user()->role=='admin'): ?>
                                <th class="border-bottom-0">طباخ </th>
                                <?php endif; ?> <th class="border-bottom-0">العمليات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($x->user->name); ?></td>
                                <td><?php echo e($x->rating); ?></td>
                                <td><?php echo e($x->note); ?></td>
                                <td><?php echo e($x->note_en); ?></td>
                                <td><?php echo e($x->chef->name); ?></td>

                                <?php if(auth()->user()->role=='admin'): ?>
                                <td><?php echo e($x->chef->name); ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($ratings->links()); ?>

                    <div class="text-center">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- row closed -->
</div>
<!-- Container closed -->
</div>
<!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\مشروع الهاكثون\first\resources\views/admin/rating/chefs.blade.php ENDPATH**/ ?>