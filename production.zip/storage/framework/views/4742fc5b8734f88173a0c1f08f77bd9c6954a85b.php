<?php $__currentLoopData = $wasfas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wasfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>countity
<?php echo e($wasfa->wasfa->name); ?>

<?php echo e($wasfa->countity); ?>

<?php echo e($wasfa->wasfa->price); ?>

<?php echo e($wasfa->created_at); ?>

<button>number</button>
<a href="<?php echo e(route('card.delete',$wasfa->id)); ?>">delete</a>
<a href="">buy</a>
<br>
<br>
<br>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

طريقة التوصيل
<input type="radio" name="self_delivery" value="1">استلم بنفسك
<input type="radio" name="self_delivery" value="0">ديلفري
12
<form action="<?php echo e(route('card.payment')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="price" value="12">
    <button>pay</button>

</form><?php /**PATH E:\مشروع الهاكثون\first\resources\views/cards/index.blade.php ENDPATH**/ ?>