<?php echo e($wasfa->name); ?>

<?php echo e($wasfa->discription); ?>

<?php echo e($wasfa->image); ?>

<?php echo e($wasfa->price); ?>

<?php echo e($wasfa->time_make); ?>

<?php echo e($wasfa->number_user); ?>

<?php echo e($wasfa->user->name); ?>

<?php echo e($wasfa->category->name); ?>

<form method="POST" method="<?php echo e(route('wasfas.store',$wasfa->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="wasfa_id" value="<?php echo e($wasfa->id); ?>">
    <input type="number" name="countity">
    <?php $__currentLoopData = $wasfa->wasfa_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="checkbox" value="<?php echo e($content->id); ?>" name="content[]">
    <img src="<?php echo e(asset('assets/wasfas_content/'.$content->image)); ?>" width="100">

    <?php echo e($content->name); ?>

    <?php echo e($content->price); ?>

    <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <textarea name="notes"><?php echo e(old('note')); ?></textarea>
    <button>add</button>
</form><?php /**PATH E:\مشروع الهاكثون\first\resources\views/wasfas/show.blade.php ENDPATH**/ ?>