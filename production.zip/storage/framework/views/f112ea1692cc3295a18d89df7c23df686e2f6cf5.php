    <!-- Essential javascripts for application to work-->
    <script src="<?php echo e(asset('admin_panel/ar/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_panel/ar/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_panel/ar/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_panel/ar/js/main.js')); ?>"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo e(asset('admin_panel/ar/js/plugins/pace.min.js')); ?>"></script>

    </body>

    </html><?php /**PATH E:\مشروع الهاكثون\first\resources\views/layouts/footer.blade.php ENDPATH**/ ?>