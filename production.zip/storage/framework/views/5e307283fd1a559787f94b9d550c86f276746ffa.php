<?php echo e($order->chef->name); ?>


<form action="<?php echo e(route('orders.ratechef.post')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="wasfa_id" value="<?php echo e($order->wasfa->id); ?>">
    <input type="hidden" name="chef_id" value="<?php echo e($order->chef->id); ?>">
    <input type="number" name="rating">
    <input type="text" name="note">
    <button>save</button>
</form><?php /**PATH E:\مشروع الهاكثون\first\resources\views/rating/chef.blade.php ENDPATH**/ ?>