
<?php $__env->startSection('content'); ?>
<!-- row -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-xl-12">
        <div class="card mg-b-20">
            <div class="card-header pb-0">
                <div class="d-flex justify-content-between">
                    <a class="modal-effect btn btn-outline-primary btn-block" data-effect="effect-scale" data-toggle="modal" href="#modaldemo8">اضافة طباخ </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered table-arabic" id="sampleTable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0">#</th>
                                <th class="border-bottom-0">wasfa </th>
                                <th class="border-bottom-0">اسم </th>
                                <th class="border-bottom-0">image </th>
                                <th class="border-bottom-0">الحالة </th>
                                <?php if(auth()->user()->role=='admin'): ?>
                                <th class="border-bottom-0">chef </th>
                                <?php endif; ?>
                                <th class="border-bottom-0">العمليات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $wasfas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($x->wasfa->name); ?></td>
                                <td><?php echo e($x->user->name); ?></td>
                                <td><img src="<?php echo e(asset('assets/wasfas/'.$x->wasfa->image)); ?>" width="100px" height="50px" /></td>
                                <td><?php echo e($x->status); ?></td>
                                <td>
                                    <?php if(auth()->user()->id == $x->chef_id ): ?>
                                    <a href="<?php echo e(route('admin.orders.show',$x->id)); ?>" title="رؤية الطلبية"><i class="fa fa-eye"></i></a>

                                    <a class="modal-effect btn btn-sm btn-info" data-name="<?php echo e($x->name); ?>" data-id="<?php echo e($x->id); ?>" data-toggle="modal" id="showEditModelCategory" href="javascript:void(0)" title="تعديل"><i class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($wasfas->links()); ?>

                    <div class="text-center">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" id="editmodelNutrl">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title"> تعديل حاله</h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.orders.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control" id="docotor_id" name="id">

                        <div class="form-group">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12 mt-4">
                                        <label for="exampleInputEmail1">status</label>
                                        <select name="status" id="status">
                                            <option value="end">مكتمل</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="btn btn-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                                <hr>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">تاكيد</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
</div>
<!-- Container closed -->
</div>
<!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<!-- Internal Data tables -->
<script>
    /**show */
    $('body').on('click', '#showModelNutr', function() {
        var nutr_val = $(this).data('id');
        $.get('/admin/chef/edit/' + nutr_val, function(data) {
            $('#showElementModel').modal('show');
        });
    });
    //لما يروح الضغط عن اضهار العناصر
    $('#showElementModel').on('hidden.bs.modal', function(event) {

        $('#element_details').find('tbody tr').remove();
    })
    $(() => {
        //edit
        $('body').on('click', '#showEditModelCategory', function() {

            var docotor_id = $(this).data('id');
            var docotor_name = $(this).data('name');

            var nutr_val = $(this).data('value');
            $.get('/admin/chef/edit/' + docotor_id, function(data) {
                $('#editmodelNutrl').modal('show');
                $('#docotor_id').val(docotor_id);
                $('#docotor_name').val(docotor_name);

                $(`#status option[value='${data[0].status}']`).prop('selected', true);

                $(`#role option[value='${data[0].role}']`).prop('selected', true);
                // status
                // role


            });
        });
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\مشروع الهاكثون\first\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>