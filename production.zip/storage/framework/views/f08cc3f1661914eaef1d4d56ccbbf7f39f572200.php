orderspendeing




orderpayment
<?php $__currentLoopData = $orderpayment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendeing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($pendeing->wasfa->name); ?>

<?php echo e($pendeing->user->name); ?>

قيد الانتظار
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br><br><br><br><br>
ordercacncle

<?php $__currentLoopData = $ordercacncle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cancle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($cancle->wasfa->name); ?>

<?php echo e($cancle->user->name); ?>

ملغي
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br><br><br><br><br>
orderend

<?php $__currentLoopData = $orderend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('orders.ratewasfa')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
    <button>تقييم طبيخ</button>
</form>
<form action="<?php echo e(route('orders.ratechef')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
    <button>تقييم الطباخ</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br><br><br>
orderfinish


<?php $__currentLoopData = $orderfinish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\مشروع الهاكثون\first\resources\views/orders/index.blade.php ENDPATH**/ ?>