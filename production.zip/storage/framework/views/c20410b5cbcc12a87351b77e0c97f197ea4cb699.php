<?php $__currentLoopData = $wasfas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wasfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($wasfa->name); ?>

<?php echo e($wasfa->discription); ?>

<?php echo e($wasfa->image); ?>

<?php echo e($wasfa->price); ?>

<?php echo e($wasfa->time_make); ?>

<?php echo e($wasfa->number_user); ?>

<?php echo e($wasfa->user->name); ?>

<?php echo e($wasfa->category->name); ?>


<a href="<?php echo e(route('wasfas.show',$wasfa->id)); ?>">send</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\مشروع الهاكثون\first\resources\views/wasfas/index.blade.php ENDPATH**/ ?>