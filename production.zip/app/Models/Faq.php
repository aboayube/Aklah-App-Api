<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\App;

class Faq extends Model
{
    use HasFactory;
    protected $fillable = ['title', 'title_en', 'status', 'body_en', 'body', 'id', 'user_id'];
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function scopeTitle($query)
    {
        if (App::getLocale() == 'ar') {
            $title = $query->first()->title;
        } else {
            $title = $query->first()->title_en;
        }
        return $title;
    }
    public function scopeBody($query)
    {
        if (App::getLocale() == 'ar') {
            $body = $query->first()->body;
        } else {
            $body = $query->first()->body_en;
        }
        return $body;
    }
}
