<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ChefsResource;
use App\Http\Resources\WasfaContentResource;
use App\Http\Resources\WasfaResource;
use App\Models\Wasfa;
use App\Models\WasfaContent;
use App\Models\WasfaUser;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

class wasfasController extends Controller
{
    public function index($lang)
    {
        $this->set_Language($lang);
        $wasfas = Wasfa::where('status', '1')->orderBy('id', 'DESC')->paginate(10);
        if ($wasfas->count() > 0) {
            return response()->json(['error' => false, 'data' => ChefsResource::collection($wasfas), 'status' => 200]);
        } else {
            return response()->json(['error' => true, 'message' => 'No wasfas found', 'status' => 200],);
        }
    }

    public function show($lang, $id)
    {
        $this->set_Language($lang);
        $wasfa = Wasfa::where('status', '1')->with('wasfa_content')->where('id', $id)->first();
        //  dd($wasfa);
        if ($wasfa) {
            return response()->json(['errors' => true, 'message' => "wasfa cotnent created", 'data' => new WasfaResource($wasfa), 'status' => 200], 200);
        } else {
            return response()->json(['errors' => true, 'message' => "return data error", 'status' => 404], 404);
        }
    }
    public function show_content($lang, $id)
    {
        $this->set_Language($lang);
        $wasfas = WasfaContent::where('wasfa_id', $id)->where('status', '1')->paginate(10);
        if ($wasfas) {
            return response()->json(['errors' => true, 'message' => "wasfa cotnent created", 'data' =>  WasfaContentResource::collection($wasfas), 'status' => 200], 200);
        } else {
            return response()->json(['errors' => true, 'message' => "return data error", 'status' => 404], 404);
        }
    }

    public function store(Request $request, $lang, $id)
    {
        $validator = Validator::make($request->all(), [
            'countity' => 'required',
            'price'        => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => true, 'message' => $validator->errors()], 200);
        }

        $this->set_Language($lang);
        $wasfa = Wasfa::where('id', $id)->where('status', '1')->first();
        if ($wasfa) {
            $note = null;
            $note_en = null;

            if ($this->language() == 'ar') {
                $note = $request->note;
            } else {
                $note_en = $request->note;
            }
            $wsafaContent = WasfaUser::create([
                'wasfa_id' => $id,
                'user_id' => auth()->id(),
                'chef_id' => $wasfa->user_id,
                'note' => $note,
                'note_en' => $note_en,
                'countity' => $request->countity,
                'price' => $request->price,
            ]);
            if ($wsafaContent) {
                return response()->json(['errors' => false, 'message' => "success add", 'status' => 201]);
            } else {
                return response()->json(['errors' => true, 'message' => "return data error", 'status' => 404]);
            }
        } else {
            return response()->json(['errors' => true, 'message' => "return data error", 'status' => 404], 404);
        }
    }
    //
}
