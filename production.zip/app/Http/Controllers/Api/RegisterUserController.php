<?php

namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

class RegisterUserController extends Controller
{

    public function login(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => true, 'data' => 'somthing was error', 'status' => 200]);
        }
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $data['user'] = new UserResource($user);
            $data['token'] = $user->createToken('my-app-token')->plainTextToken;
            return response()->json(['error' => false, 'data' => $data, "status" => 200]);
        } else {

            return response()->api([], 1, __('auth.failed'));
        } //end of else

    }
    //
    public function register(Request $request, $lang)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:3|string',
            'username' => 'required|min:3|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'mobile' => 'required|numeric|min:10',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => 'true', 'message' => $validator->errors()->first(), 'status' => 200]);
        }
        $name = null;
        $name_en = null;
        if ($this->language() == 'ar') {
            $name = $request->name;
        } else {
            $name_en = $request->name;
        }
        $user = User::create([
            'name' => $name,
            'name_en' => $name_en,
            'username' => $request->username,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'mobile' => $request->mobile,
            'role' => 'user',
            'status' => '1',
        ]);
        $user->assignRole('user');
        $data['user'] = new UserResource($user);
        $data['token'] = $user->createToken('my-app-token')->plainTextToken;

        return response()->json(['error' => false, 'data' => $data, 'status' => 200], 200);
    }

    public function address(Request $request, $lang)
    {
        $this->language($lang);
        $validator = Validator::make($request->all(), [
            'address' => 'required|min:3|string',
            'lat' => 'required|numeric',
            'lng' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => 'true', 'message' => $validator->errors()->first(), 'status' => 200]);
        }
        $user = User::find(auth()->id());
        $user->address = $request->address;
        $user->longtoitle = $request->lat;
        $user->attuite = $request->lng;
        $user->save();
        return response()->json(['error' => false, 'data' => new UserResource($user), 'status' => 200], 200);
    }
}
